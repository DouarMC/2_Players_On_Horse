import { world } from "@minecraft/server";
export class ALL_DATAS {
}
ALL_DATAS.allDimensions = [world.getDimension("minecraft:overworld"), world.getDimension("minecraft:nether"), world.getDimension("minecraft:the_end")];
;
