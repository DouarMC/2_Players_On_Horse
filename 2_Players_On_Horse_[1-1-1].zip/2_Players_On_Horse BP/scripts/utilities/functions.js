import { ALL_DATAS } from "./datas";
export class ALL_FUNCTIONS {
    /**
     * Renvoie les Entités qui correspondent à la requête, de toutes les dimensions.
     * @param options La requête de recherche d'entités.
     * @returns
     */
    static getEntitiesFromAllDimensions(options) {
        const entities = [];
        for (const dimension of ALL_DATAS.allDimensions) {
            entities.push(...dimension.getEntities(options));
        }
        ;
        return entities;
    }
    ;
    /**
     * Renvoie les Entités qui correspondent aux requêtes, de toutes les dimensions.
     * @param entityQueries Les requêtes de recherche d'entités.
     * @returns
     */
    static getEntitiesFromAllDimensionsWithMultipleQueries(entityQueries) {
        const entities = [];
        for (const entityQuery of entityQueries) {
            entities.push(...this.getEntitiesFromAllDimensions(entityQuery));
        }
        ;
        const entitiesId = [];
        for (let i = 0; i < entities.length; i++) {
            if (entitiesId.includes(entities[i].id) === true) {
                entities.splice(i, 1);
                i--;
            }
            else {
                entitiesId.push(entities[i].id);
            }
            ;
        }
        ;
        return entities;
    }
    ;
}
;
