export * from "entities/groups/equids";
