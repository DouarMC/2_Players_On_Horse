import { system } from "@minecraft/server";
import { ALL_FUNCTIONS } from "utilities/functions";
system.runInterval(() => {
    const entityQueries = [{ type: "horse" }, { type: "donkey" }, { type: "mule" }];
    const equids = ALL_FUNCTIONS.getEntitiesFromAllDimensionsWithMultipleQueries(entityQueries);
    for (const equid of equids) {
        if (equid.hasComponent("minecraft:inventory") === false)
            return;
        const equidInventoryComponent = equid.getComponent("minecraft:inventory");
        const equidContainer = equidInventoryComponent.container;
        const slotSaddleItemStack = equidContainer.getItem(0);
        if (slotSaddleItemStack === undefined) {
            equid.setProperty("douarmc:saddle_equipped_type", "saddle");
        }
        else if (slotSaddleItemStack.typeId === "minecraft:saddle") {
            equid.setProperty("douarmc:saddle_equipped_type", "saddle");
        }
        else if (slotSaddleItemStack.typeId === "douarmc:double_saddle") {
            equid.setProperty("douarmc:saddle_equipped_type", "double_saddle");
        }
        ;
    }
    ;
});
